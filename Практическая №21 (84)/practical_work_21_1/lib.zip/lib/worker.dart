class Worker{
  String name = "";
  String? phone = "";
  String email = "";
  String? gender = 'Мужской';
  String age = "";
  String? metro = "";
  String? persQua = "";
  List<bool> ab =[ false, false, false, false, false, false, false, false,];
}